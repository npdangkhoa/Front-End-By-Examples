$(document).ready(function(){
	var $btn = $("#btn"),
		$list = $("#list");

	$btn.click(function(evt){
		// TODO
	});

	// TODO: setup sampled sequence, populate $list
});
