$(document).ready(function(){
	var $btn = $("#btn"),
		$list = $("#list");

	$btn.click(/* TODO */);

	// Hint: ASQ().runner( .. )

	// TODO: setup sampling go-routine and
	// channel, populate $list
});
